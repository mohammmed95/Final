<style>
    table {
        border-collapse: collapse;
        width: 100%;
    }

    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    tr:hover{background-color:#996633;color: white}
</style>
<?php
//this is the header part for my cms
require 'parts/header.php'; ?>

<div id="content">
    <?php
    //this is the sidebar part for my cms
    require 'parts/sidebar.php'; ?>
    <div id="main">
        <div id="example" class="right-box">
            <h2 class="title">Blog Page</h2>
            <div class="content">
                <a href="add.php" class="button">Add Blog</a>
                <?php $sql = "SELECT * FROM blog ORDER BY id DESC";
                $result = mysqli_query($con,$sql);
                $data = [];
                while ($row = mysqli_fetch_assoc($result)):
                    $data[] = $row;
                endwhile;
                ?>
                <table>
                    <tr>
                        <th>Title</th>
                        <th>Post</th>
                        <th>Action</th>
                    </tr>
                    <?php foreach ($data as $item): ?>
                    <tr>
                        <td><?= $item['title'] ?></td>
                        <td><?= $item['post'] ?></td>
                        <td>
                            <a class="button button2" href="update.php?id=<?= $item['id'] ?>">Update</a>
                            <a class="button button3" href="delete.php?id=<?= $item['id'] ?>">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>


                </table>
            </div>
        </div>
    </div>
</div>
<?php

require 'parts/footer.php'; ?>