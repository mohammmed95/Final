
<div id="footer" class="center-box">
    <p id="legal">Copyright &copy; 2007 Pure n' Simple. All Rights Reserved. Designed by <a href="http://www.freecsstemplates.org/">Free CSS Templates</a>.</p>
    <p id="links"><a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a></p>
</div>
</html>

<?php mysqli_close($con); ?>