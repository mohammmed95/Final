<?php
require 'session.php';
require 'conf.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Main Page</title>
    <link href="https://fonts.googleapis.com/css?family=Ubuntu+Mono" rel="stylesheet">
    <link href="css/default.css" rel="stylesheet" type="text/css" />

    <style>
        body{
            font-family: 'Ubuntu Mono', monospace!important;
        }
        .button {
            background-color: #4CAF50; /* Green */
            border: none;
            color: white;
            padding: 5px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 11pt;
            margin: 4px 2px;
            cursor: pointer;
        }
        input[type=text], input[type=password] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        .button2 {background-color: #008CBA;} /* Blue */
        .button3 {background-color: #f44336;} /* Red */
        .button4 {background-color: #e7e7e7; color: black;} /* Gray */
        .button5 {background-color: #555555;} /* Black */
    </style>
</head>
<body>
<div id="logo" class="center-box">
    <h1><a href="#">CMS</a></h1>
    <h2>Welcome <?= $_SESSION['login'] ?></h2>
</div>