<div id="sidebar">
    <div id="menu" class="left-box">
        <h2 class="title">Menu</h2>
        <div class="content">
            <ul>
                <li><a href="main.php" title="">Homepage</a></li>
                <li><a href="blog.php" title="">Blogs</a></li>
                <li><a href="upload.php" title="">Upload Image</a></li>
                <li class="button button3">
                    <a style="color: #f1f1f1" href="logout.php" title="">Logout</a>
                </li>

            </ul>
        </div>
    </div>
</div>