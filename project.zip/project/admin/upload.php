<?php
//this is the header part for my cms
require 'parts/header.php'; ?>

    <div id="content">
        <?php
        //this is the sidebar part for my cms
        require 'parts/sidebar.php'; ?>
        <div id="main">
            <div id="example" class="right-box">
                <h2 class="title">Upload Image</h2>
                <div class="content">

                    <form action="post/upload_test.php" method="post" enctype="multipart/form-data">
                        Upload
                        <input type="file" placeholder="add post" name="image" required>
                        <input type="submit" value="Upload" class="button button2">
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php
//this is the footer part for my cms
require 'parts/footer.php'; ?>