<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/css?family=Ubuntu+Mono" rel="stylesheet">
    <title>Login</title>
    <style>
        body{
            font-family: 'Ubuntu Mono', monospace!important;
        }
        form {
            border: 3px solid #f1f1f1;
            background-color: #f1f1f1;
        }

        input[type=text], input[type=password] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            opacity: 0.8;
        }

        .container {
            width: 60%;
            margin-left: auto;
            margin-right: auto;
            padding: 16px;
        }

    </style>
</head>
<body>

<h2 style="text-align: center">Login Form</h2>
<?php
session_start();
if (isset($_SESSION['errors'])){
    echo $_SESSION['errors'];
    unset($_SESSION['errors']);
}
?>
<form class="container" action="post/login_post.php" method="post">
    <div >
        <label><b>Username</b></label>
        <input type="text" placeholder="Enter Username" name="username" required>

        <label><b>Password</b></label>
        <input type="password" placeholder="Enter Password" name="password" required>

        <button type="submit">Login</button>
    </div>


</form>

</body>
</html>