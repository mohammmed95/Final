
<?php
//this is the header part for my cms
require 'parts/header.php'; ?>

<div id="content">
    <?php
    //this is the sidebar part for my cms
    require 'parts/sidebar.php'; ?>
    <div id="main">
        <div id="example" class="right-box">
            <h2 class="title">Main Page</h2>
            <div class="content">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque dignissimos error excepturi inventore molestiae similique voluptas. Aliquid aperiam aspernatur dolorum facere mollitia pariatur, placeat quibusdam, quidem quis repellat similique, suscipit?
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Animi asperiores, corporis dicta dignissimos doloremque est fugiat id illum iusto maiores maxime nesciunt pariatur perspiciatis, quaerat repudiandae sunt tempore vel veniam.
            </div>
        </div>
    </div>
</div>
<?php
//this is the footer part for my cms
require 'parts/footer.php'; ?>