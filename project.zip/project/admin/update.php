<?php
//this is the header part for my cms
require 'parts/header.php'; ?>

    <div id="content">
        <?php
        //this is the sidebar part for my cms
        require 'parts/sidebar.php'; ?>
        <div id="main">
            <div id="example" class="right-box">
                <h2 class="title">Update Blog</h2>
                <div class="content">
                    <?php $id = $_GET['id'];
                    $sql = "SELECT * FROM blog WHERE id ='$id'";
                    $result = mysqli_query($con, $sql);
                    $data = [];
                    while ($row = mysqli_fetch_assoc($result)):
                        $data[] = $row;
                    endwhile;
                    ?>
                    <?php foreach ($data as $item): ?>
                        <form action="post/update_post.php?id=<?= $id ?>" method="post">
                            <input type="text" value="<?= $item['title'] ?>" name="title" required>
                            <br>
                            <input type="text" value="<?= $item['post'] ?>" name="post" required>
                            <br>
                            <select name="section">

                                <?php
                                $sql = "SELECT * FROM section";
                                $result = mysqli_query($con, $sql);
                                $data2 = [];
                                while ($row = mysqli_fetch_assoc($result)):
                                    $data2[] = $row;
                                endwhile;


                                foreach ($data2 as $item2): ?>
                                    <?php if ($item['section'] == $item2['id']): ?>
                                        <option selected value="<?= $item2['id'] ?>"><?= $item2['name'] ?></option>
                                    <?php else: ?>
                                        <option value="<?= $item2['id'] ?>"><?= $item2['name'] ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>


                            </select>
                            <br>
                            <input type="submit" value="Update" class="button button2">
                        </form>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
<?php
//this is the footer part for my cms
require 'parts/footer.php'; ?>