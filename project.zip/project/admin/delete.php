<?php
//this is the header part for my cms
require 'parts/header.php'; ?>

    <div id="content">
        <?php
        //this is the sidebar part for my cms
        require 'parts/sidebar.php'; ?>
        <div id="main">
            <div id="example" class="right-box">
                <h2 class="title">Update Blog</h2>
                <div class="content">
                    <?php $id = $_GET['id'];
                    $sql = "SELECT * FROM blog WHERE id ='$id'";
                    $result = mysqli_query($con, $sql);
                    $data = [];
                    while ($row = mysqli_fetch_assoc($result)):
                        $data[] = $row;
                    endwhile;
                    ?>
                    <?php foreach ($data as $item): ?>
                        <form action="post/delete_post.php?id=<?= $id ?>" method="post">
                            <h1>Are You Sure To Delete This Blog ?</h1>
                            <h2><?= $item['title'] ?></h2>
                            <h2><?= $item['post'] ?></h2>
                            <input type="submit" value="Delete" class="button button3">
                            <a href="blog.php" class="button button2">Back to Blog</a>
                        </form>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
<?php
//this is the footer part for my cms
require 'parts/footer.php'; ?>