<?php
require '../conf.php';

$id = $_GET['id'];


$sql = "DELETE FROM blog WHERE id = '$id'";

if (mysqli_query($con,$sql))
    header('location:../blog.php');
else
    echo 'ERROR!!';