<?php
require '../conf.php';

$filename = $_FILES['image']['name'];

$uploadOk = 1;

$imageFileType = pathinfo($filename, PATHINFO_EXTENSION);


if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}



if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
} else {
    $target_dir = "../uploads/";

    $our_file_name = "moh_" . rand();

    $the_full_path_to_the_file = $target_dir . $our_file_name . '.' . $imageFileType;

    move_uploaded_file($_FILES["image"]["tmp_name"],$the_full_path_to_the_file );

    $query = "INSERT INTO file (filename) VALUES ('$our_file_name"."."."$imageFileType')";

    if (mysqli_query($con,$query))
        header('location:../upload.php');
    else
        echo "The Error in the SQL Uploading";
}