<?php
session_start();

require '../conf.php';

$username = $_POST['username'];
$password =  $_POST['password'];

$sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";

$result = mysqli_query($con,$sql);


if ($row = mysqli_fetch_assoc($result))
{
    $_SESSION['login'] = $row['username'];
    header('location:../main.php');
    die();
}
else{
    $_SESSION['errors']='have invalid username or password error';
    header('location:../index.php');
}
