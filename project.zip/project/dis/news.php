<?php
require 'index.php';
require '../admin/conf.php';

$id = $_GET['id'];

$sql = "SELECT * FROM blog WHERE section='$id' ORDER BY id DESC";
                $result = mysqli_query($con,$sql);
                $data = [];
                while ($row = mysqli_fetch_assoc($result)):
                    $data[] = $row;
                endwhile;
                ?>
<div class=" ta">
    <style>
        table {
            width:100%;
        }
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        th, td {
            padding: 5px;
            text-align: left;
        }
        table#t01 tr:nth-child(even) {
            background-color: #eee;
        }
        table#t01 tr:nth-child(odd) {
            background-color:#fff;
        }
        table#t01 th {
            background-color: black;
            color: white;
        }
    </style>
<table border="2"">
    <tr>
        <th>Title</th>
        <th>Post</th>
        <th>Action</th>
    </tr>
    <?php foreach ($data as $item): ?>
        <tr>
            <td><?= $item['title'] ?></td>
            <td><?= $item['post'] ?></td>
            <td>
                <a class="button button2" href="update.php?id=<?= $item['id'] ?>">Update</a>
                <a class="button button3" href="delete.php?id=<?= $item['id'] ?>">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>


    <!--                    --><?php //foreach ($data as $item): ?>
    <!--                        <img src="../upload/--><?//= $item['filename'] ?><!--" alt="">-->
    <!--<!--                        <img src="upload/312312331.jpg" alt="">-->-->
    <!--                    --><?php //endforeach; ?>
</table></div>