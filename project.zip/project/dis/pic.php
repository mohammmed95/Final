<?php
require 'index.php';
require '../admin/conf.php';

$sql = "SELECT * FROM file  ORDER BY id DESC";
$result = mysqli_query($con, $sql);
$data = [];
while ($row = mysqli_fetch_assoc($result)):
    $data[] = $row;
endwhile;
?>


<div class="container">
    <div class="carousel">
        <input type="radio" id="carousel-1" name="carousel[]" checked>
        <input type="radio" id="carousel-2" name="carousel[]">
        <input type="radio" id="carousel-3" name="carousel[]">
        <input type="radio" id="carousel-4" name="carousel[]">
        <input type="radio" id="carousel-5" name="carousel[]">
        <ul class="carousel__items">
            <?php foreach ($data as $item): ?>
                <li class="carousel__item">
                    <img src="../admin/uploads/<?= $item['filename'] ?>" alt="">
                </li>
            <?php endforeach; ?>
        </ul>
        <div class="carousel__prev">
            <label for="carousel-1"></label>
            <label for="carousel-2"></label>
            <label for="carousel-3"></label>
            <label for="carousel-4"></label>
            <label for="carousel-5"></label>
        </div>
        <div class="carousel__next">
            <label for="carousel-1"></label>
            <label for="carousel-2"></label>
            <label for="carousel-3"></label>
            <label for="carousel-4"></label>
            <label for="carousel-5"></label>
        </div>
        <div class="carousel__nav">
            <label for="carousel-1"></label>
            <label for="carousel-2"></label>
            <label for="carousel-3"></label>
            <label for="carousel-4"></label>
            <label for="carousel-5"></label>
        </div>
    </div>
</div>
